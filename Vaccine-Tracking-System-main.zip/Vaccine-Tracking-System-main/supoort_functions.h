#pragma once
class supoort_functions
{
public :
	static int cal(int x, int y)
	{
		return x + y;
	}
};

